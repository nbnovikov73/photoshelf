# PhotoShelf

PhotoShelf is an Astro-first personal photography publishing system.

It exists for one reason:

> Publish a carefully selected photograph to your own website from your phone with almost Instagram-level simplicity.

PhotoShelf is not a social network, not a generic CMS, and not a portfolio template. It is a quiet, fast, editorial publishing tool for photographers who want to own their archive.

## Core stack

- Astro
- TypeScript
- React islands for admin interactivity only
- PostgreSQL
- Prisma
- S3-compatible storage
- Sharp
- Docker Compose

## Core flow

```txt
Upload → Preview → Edit minimal metadata → Publish
```

## Project documents

Read these before implementing anything:

1. `PRD.md`
2. `ARCHITECTURE.md`
3. `CODING_RULES.md`
4. `docs/00_PRODUCT_VISION.md`
5. `.codex/SKILL.md`

## MVP goal

The MVP is complete when a user can open the admin from a phone, upload a photograph, generate optimized image variants, extract basic EXIF metadata, add title/description/series/tags, publish the photograph, and see it on the public Astro site.

## What PhotoShelf must not become

- Instagram clone
- WordPress clone
- multi-user SaaS
- social feed
- dashboard-heavy CMS
- over-engineered architecture experiment
